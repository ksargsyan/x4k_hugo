#!/usr/bin/env python

from nn_utils import *


# Read the NN surrogate
elm_nn = pk.load(open('elm_nn.pk', 'rb'))

# Read training input/outputs
x = np.loadtxt('qtrain.txt')
y = np.loadtxt('ytrain.txt')
nout = y.shape[1]

# Evaluate NN surrogate at training inputs
y_nn = elm_nn(tch.tensor(x, requires_grad=False)).data.numpy()
nsam = y_nn.shape[0]

# Plot parity figures
for iout in range(nout):
    plt.figure(figsize=(6,6))
    plt.plot(y[:, iout], y_nn[:, iout], 'bo')
    
    ymin, ymax = y[:, iout].min(), y[:, iout].max()
    delt = 0.03 * (ymax-ymin)
    plt.plot([ymin - delt, ymax + delt], [ymin - delt, ymax + delt], 'k--', linewidth=2)
    plt.xlabel('ELM')
    plt.ylabel('ELM_NN')
    plt.savefig(f'fit_output_{iout+1}_all.png')
    plt.clf()

# Another way to plot: select some samples and plot all outputs in temporal axis
for isam in range(nsam)[::33]:
    plt.figure(figsize=(10,6))
    plt.plot(np.arange(1, nout+1), y[isam, :], 'bo')
    plt.plot(np.arange(1, nout+1), y_nn[isam, :], 'mo-')
    plt.title(f'Sample # {isam+1}')
    plt.xlabel('Month')
    plt.ylabel('GPP')
    plt.savefig('fit_sample_'+str(isam+1).zfill(3)+'.png')
    plt.clf()
