#!/usr/bin/env python

from nn_utils import *

trnfactor = 0.8
valfactor = 0.1
assert(trnfactor+valfactor<=1.0)

# Read trainin input/outputs
x = np.loadtxt('qtrain.txt')
y = np.loadtxt('ytrain.txt')
pnames = np.loadtxt('pnames.txt', dtype=str)


nsam, ndim = x.shape
nsam_, nout = y.shape
ndim_,  = pnames.shape

assert(nsam == nsam_)
assert(ndim == ndim_)

outnames = ['January', 'February', 'March', 'April', 'May', 'June',
          'July', 'August', 'September', 'October', 'November', 'December']


ntrn = int(trnfactor * nsam)
nval = int(valfactor * nsam)
ntst = nsam - ntrn - nval
assert(ntst>=0)
print(f"Number of training points   : {ntrn}")
print(f"Number of validation points : {nval}")
print(f"Number of testing points    : {ntst}")

rperm = np.random.permutation(nsam)
indtrn = rperm[:ntrn]
indval = rperm[ntrn:ntrn+nval]
indtst = rperm[ntrn+nval:]

################################################################################
################################################################################


# Divide into Training, Validation (used during training to pick the best model), Testing
xtrn, ytrn = x[indtrn], y[indtrn]
xval, yval = x[indval], y[indval]
xtst, ytst = x[indtst], y[indtst]


# Model to fit
nnet = MLP_simple([ndim, 11,11,11, nout])


# Fitting and saving the best model
fit_results = nnfit(nnet, xtrn, ytrn, val=[xval, yval])
best_model = fit_results['best_nnmodel']
pk.dump(best_model, open('elm_nn.pk', 'wb'), -1)

# Plotting parity plots for visual inspection
ytrn_nn = best_model(tch.tensor(xtrn, requires_grad=False)).data.numpy()
yval_nn = best_model(tch.tensor(xval, requires_grad=False)).data.numpy()
if ntst > 0:
    ytst_nn = best_model(tch.tensor(xtst, requires_grad=False)).data.numpy()

# Plot parity figures for visual inspection
for iout in range(nout):
    plt.figure(figsize=(6,6))
    plt.plot(ytrn[:, iout], ytrn_nn[:, iout], 'bo', label='Training')
    plt.plot(yval[:, iout], yval_nn[:, iout], 'go', label='Validation')
    if ntst > 0:
        plt.plot(ytst[:, iout], ytst_nn[:, iout], 'ro', label='Testing')

    ymin, ymax = ytrn[:, iout].min(), ytrn[:, iout].max()
    delt = 0.03 * (ymax-ymin)
    plt.plot([ymin - delt, ymax + delt], [ymin - delt, ymax + delt], 'k--', linewidth=2)
    plt.title(outnames[iout])
    plt.xlabel('ELM')
    plt.ylabel('ELM_NN')
    plt.legend()
    plt.savefig(f'fit_output_{iout+1}.png')
    plt.clf()
