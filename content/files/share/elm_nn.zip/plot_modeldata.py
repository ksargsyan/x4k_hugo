#!/usr/bin/env python

from nn_utils import *


# Read the NN surrogate
elm_nn = pk.load(open('elm_nn.pk', 'rb'))
# Read observational data
obsdata=np.loadtxt('obsdata_all.txt')
nout_, ny = obsdata.shape

# Sample random inputs for the NN
nsam, npar = 133, 10
x = 2.*np.random.rand(nsam, npar)-1.

# Evaluate NN model
y_nn = elm_nn(tch.tensor(x, requires_grad=False)).data.numpy()
nout = y_nn.shape[1]

# Plot NN model and the observational data together
plt.figure(figsize=(10,6))
for ii in range(nsam):
    plt.plot(np.arange(1, nout+1), y_nn[ii, :], 'mo-')
for ii in range(ny):
    plt.plot(np.arange(1, nout+1), obsdata[:, ii], 'ko-')

plt.xlabel('Month')
plt.ylabel('GPP')
plt.savefig('model_data.png')



