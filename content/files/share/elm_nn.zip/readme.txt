This package helps build (nn_fit) and use (nn_eval, plot_modeldata) NN surrogate for ELM. The ELM and ELM_NN are of the form y=f(t, p), where p is 10-dimensional parameter vector, and t is indexing the model outputs (12 months), i.e. the output is 12-dimensional.

- Minimum necessary files:
	-- elm_nn.pk  : pickle file that contains the NN model which approximates E3SM Land Model (ELM) output
	-- obsdata_all.txt : 12x15 observational data, 12 outputs (months), sampled at 15 different years. You can pick a year, average over years, or use all samples - your call.
	-- plot_modeldata.py : evaluates ELMNN at randomly selected inputs (note that inputs are scaled to hypercube [-1,1]^d for d=10), and plots the results, together with the observational data.
	-- nn_utils.py : utilities for training and evaluating NN (otherwise pickle won't unpickle)


- Additional files:
	-- nn_fit.py : you can refit a NN surrogate to avoid having to read the pickle
	-- ytrain.txt: actual ELM simulations to help create NN surrogate
	-- ptrain.txt: 275x10 inputs for training ELMNN
	-- qtrain.txt: same, scaled to [-1,1]^10
	-- pnames.txt : 10 input parameter names
	-- prange.txt : 10 input parameter ranges
	-- nn_eval.py : evaluate the pre-constructed ELMNN surrogate. Can be useful to create 'data variance' error nugget for the inverse problem.

- Need numpy, matplotlib, pickle and torch.

- Bunch of .png files will be created for visual sanity checks. Let me know if they are difficult to interpret.

- This is monthly-resolved GPP output at a US-Ha1 fluxnet site (https://ameriflux.lbl.gov/sites/siteinfo/US-Ha1). If needed, we can repeat the exercise for any location on Earth, or at least at a set of sites of interest. Or, at the expense of increasing output dimensionality, add all sites into a vectorized output.

- You should be able to run all .py files (except nn_utils.py) out of the box without errors. Otherwise, I am to blame - please ask.