#!/usr/bin/env python

import copy
import numpy as np
import torch as tch
import pickle as pk
import matplotlib.pyplot as plt
tch.set_default_dtype(tch.double)

class MLP_simple(tch.nn.Module):
    r"""Simple MLP example.

    Attributes:
        biasorno (bool): Whether to use bias or not.
        hls (tuple[int]): List of layer widths.
        indim (int): Input dimensionality :math:`d_{in}`.
        outdim (int): Output dimensionality :math:`d_{out}`.
        model (torch.nn.Sequential): The Pytorch Sequential model behind the forward function.
    """

    def __init__(self, hls, biasorno=True):
        """Initialization.

        Args:
            hls (tuple[int]): Tuple  of number of units per layer, length  of list if  number of layers
            biasorno (bool, optional): Whether to use bias or not. Defaults to True.
        """
        super().__init__()
        assert(len(hls)>1)
        self.hls = hls[1:-1]
        self.indim = hls[0]
        self.outdim = hls[-1]
        self.biasorno = biasorno

        modules = []
        for j in range(len(hls)-2):
            modules.append(tch.nn.Linear(hls[j], hls[j+1], self.biasorno))
            modules.append(tch.nn.ReLU())
        modules.append(tch.nn.Linear(hls[-2], hls[-1], bias=self.biasorno))

        self.model = tch.nn.Sequential(*modules)

    def forward(self, x):
        r"""Forward function.

        Args:
            x (torch.Tensor): Input tensor `x` of size :math:`(N,d_{in})`.

        Returns:
            torch.Tensor: Output tensor of size :math:`(N,d_{out})`.
        """

        return self.model(x)

##############################################################################

def nnfit(nnmodel, xtrn, ytrn, val=None,
          lrate=0.1, nepochs=5000, batch_size=None,
          freq_out=100, freq_plot=1000
          ):
    """Generic Pytorch NN fit function that is utilized in appropriate NN classes.

    Args:
        nnmodel (torch.nn.Module): The Pytch NN module of interest.
        xtrn (np.ndarray): Training input array `x` of size `(N,d)`.
        ytrn (np.ndarray): Training output array `y` of size `(N,o)`.
        val (tuple, optional): `x,y` tuple of validation points. Default uses the training set for validation.
        lrate (float, optional): Learning rate or learning rate schedule factor. Default is 0.1.
        nepochs (int, optional): Number of epochs.
        batch_size (int, optional): Batch size. Default is None, i.e. single batch.
        freq_out (int, optional): Frequency, in epochs, of screen output. Defaults to 100.
        freq_plot (int, optional): Frequency, in epochs, of plotting loss convergence graph. Defaults to 1000.

    Returns:
        dict: Dictionary of the results. Keys 'best_fepoch', 'best_epoch', 'best_loss', 'best_nnmodel', 'history'.
    """

    ntrn = xtrn.shape[0]

    # Loss function
    loss = tch.nn.MSELoss(reduction='mean')
    def loss_xy(x, y):
        return loss(nnmodel(x), y)

    # Optimizer selection
    opt = tch.optim.Adam(nnmodel.parameters(), lr=lrate)



    if batch_size is None or batch_size > ntrn:
        batch_size = ntrn



    xtrn_ = tch.tensor(xtrn, requires_grad=True)
    ytrn_ = tch.tensor(ytrn, requires_grad=True)

    # Validation data
    if val is None:
        xval, yval = xtrn.copy(), ytrn.copy()
    else:
        xval, yval = val


    xval_ = tch.tensor(xval, requires_grad=True)
    yval_ = tch.tensor(yval, requires_grad=True)

    # Training process
    fit_info = {'best_fepoch': 0, 'best_epoch': 0,
                'best_loss': 1.e+100, 'best_nnmodel': nnmodel,
                'history': []}


    fepoch = 0
    for t in range(nepochs):
        permutation = tch.randperm(ntrn)
        # for parameter in model.parameters():
        #     print(parameter)
        nsubepochs = len(range(0, ntrn, batch_size))
        for i in range(0, ntrn, batch_size):
            indices = permutation[i:i + batch_size]

            loss_trn = loss_xy(xtrn_[indices, :], ytrn_[indices, :])
            #loss_val = loss_trn
            with tch.no_grad():
                loss_val = loss_xy(xval_, yval_)
            #loss_trn_full = loss_trn
            if i == 0:  # otherwise too expensive
                with tch.no_grad():
                    loss_trn_full = loss_xy(xtrn_, ytrn_)

            fepoch += 1. / nsubepochs

            curr_state = [fepoch + 0.0, loss_trn.item(), loss_trn_full.item(), loss_val.item()]
            crit = loss_val.item()

            fit_info['history'].append(curr_state)

            if crit < fit_info['best_loss']:
                fit_info['best_loss'] = crit
                fit_info['best_nnmodel'] = copy.copy(nnmodel)

                fit_info['best_fepoch'] = fepoch
                fit_info['best_epoch'] = t

            opt.zero_grad()
            loss_trn.backward()

            opt.step()


        ## Printout to screen
        if t == 0:
            print('{:>10} {:>10} {:>12} {:>12} {:>12} {:>18} {:>10}'.\
                  format("NEpochs", "NUpdates",
                         "BatchLoss", "TrnLoss", "ValLoss",
                         "BestLoss (Epoch)", "LrnRate"), flush=True)

        if (t + 1) % freq_out == 0 or t == 0 or t == nepochs - 1:
            tlr = opt.param_groups[0]['lr']
            printout = f"{t+1:>10}" \
                  f"{len(fit_info['history']):>10}" \
                  f"{fit_info['history'][-1][1]:>14.6f}" \
                  f"{fit_info['history'][-1][2]:>13.6f}" \
                  f"{fit_info['history'][-1][3]:>13.6f}" \
                  f"{fit_info['best_loss']:>14.6f} ({fit_info['best_epoch']})" \
                  f"{tlr:>10}"
            print(printout, flush=True)

        ## Plotting
        if t % freq_plot == 0 or t == nepochs - 1:
            fepochs = [state[0] for state in fit_info['history']]
            losses_trn = [state[1] for state in fit_info['history']]
            losses_trn_full = [state[2] for state in fit_info['history']]
            losses_val = [state[3] for state in fit_info['history']]

            _ = plt.figure(figsize=(12, 8))

            plt.plot(fepochs, losses_trn, label='Batch loss')
            plt.plot(fepochs, losses_trn_full, label='Training loss')
            plt.plot(fit_info['best_fepoch'], fit_info['best_loss'],
                     'ro', markersize=11)
            plt.vlines(fit_info['best_fepoch'], 0.0, 2.0,
                       colors=None, linestyles='--')
            plt.plot(fepochs, losses_val, label='Validation loss')

            plt.legend()

            plt.savefig(f'loss_history.png')
            plt.yscale('log')
            plt.savefig(f'loss_history_log.png')
            plt.clf()

    return fit_info

#############################################################################
#############################################################################
#############################################################################
